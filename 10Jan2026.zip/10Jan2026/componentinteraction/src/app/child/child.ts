import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  imports: [],
  templateUrl: './child.html',
  styleUrl: './child.css',
})
export class Child implements OnInit {

   @Input() apiKeyFromParent:string='';

   ngOnInit():void{
     console.log("API Key received from Parent Component: ", this.apiKeyFromParent);
   }

}
