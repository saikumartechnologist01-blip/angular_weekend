import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  imports: [FormsModule,CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {

   username:string='';
    password:string='';

  onLogin(){
   event?.preventDefault();
    console.log("Username:", this.username);
    console.log("Password:", this.password);
    
    if(this.username === 'admin' && this.password === 'admin123'){
      alert('Login Successful!');
    }
    else{
        alert('Invalid Credentials. Please try again.');
    }

  }

}
