import { CurrencyPipe, DatePipe, UpperCasePipe } from '@angular/common';
import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ReversePipe } from './reverse-pipe';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, DatePipe,UpperCasePipe,CurrencyPipe,ReversePipe],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
 
   today = new Date();

   companyName= "Intellipaat Technologies";

   billAmount= 25000;

   description= "Angular is a platform for building mobile and desktop web applications.";

}
