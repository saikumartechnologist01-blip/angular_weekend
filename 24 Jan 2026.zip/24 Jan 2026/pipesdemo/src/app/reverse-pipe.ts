import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'reverse',
})
export class ReversePipe implements PipeTransform {

  transform(value: unknown): unknown {

    var finalValue = value;

    if (typeof value === 'string') {
      finalValue= value.split('').reverse().join('');
    }
    return finalValue

  }

}
