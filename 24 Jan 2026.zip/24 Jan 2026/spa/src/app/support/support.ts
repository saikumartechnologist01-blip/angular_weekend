import { Component } from '@angular/core';

@Component({
  selector: 'app-support',
  imports: [],
  templateUrl: './support.html',
  styleUrl: './support.css',
})
export class Support {

}
