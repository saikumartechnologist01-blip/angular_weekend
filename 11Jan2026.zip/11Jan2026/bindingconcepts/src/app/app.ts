import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
 
   data="";

  placeholderText= "Enter your username";
  imageSrc ="https://rukminim2.flixcart.com/image/612/612/xif0q/speaker/h/n/y/-original-imahg5zyabpetdb4.jpeg?q=70";
  
   showData(){
            this.data="Welcome to Angular Binding Concepts"; 
   }

}
