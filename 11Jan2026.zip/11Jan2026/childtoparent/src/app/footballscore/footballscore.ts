import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-footballscore',
  imports: [],
  templateUrl: './footballscore.html',
  styleUrl: './footballscore.css',
})
export class Footballscore {


   score:string = "";

   @Output() footballScoreChange= new EventEmitter<string>();

   generateRandomScore(){
    return Math.floor(Math.random() * 10).toString() + "-" + Math.floor(Math.random() * 10).toString(); //
   }
   
   getScore(){
    this.score = this.generateRandomScore();
    this.footballScoreChange.emit(this.score);
   }

}
