import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Footballscore } from './footballscore';

describe('Footballscore', () => {
  let component: Footballscore;
  let fixture: ComponentFixture<Footballscore>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Footballscore]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Footballscore);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
