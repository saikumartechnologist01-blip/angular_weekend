import { Component } from '@angular/core';
import { Cricketscore } from '../cricketscore/cricketscore';
import { Footballscore } from '../footballscore/footballscore';

@Component({
  selector: 'app-scores',
  imports: [Cricketscore,Footballscore],
  templateUrl: './scores.html',
  styleUrl: './scores.css',
})
export class Scores {

   cricketScore:string="";
   footballScore:string="";

  scoreChangeHandler(scoreInfo:string){
     this.cricketScore = scoreInfo;
  }
  scoreChangeHandlerFootball(scoreInfo:string){
     this.footballScore = scoreInfo;
  }

}
