import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SupportService {
  

  constructor(private httpClient:HttpClient){

  }

   getSupportUsersInfo(){
     return this.httpClient.get("https://fakestoreapi.com/users");
   }


}
