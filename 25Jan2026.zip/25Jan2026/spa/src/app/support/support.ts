import { Component } from '@angular/core';
import { SupportService } from '../support';


@Component({
  selector: 'app-support',
  imports: [],
  templateUrl: './support.html',
  styleUrl: './support.css',
})
export class Support {

  constructor(private supportService:SupportService){

  }
  fetchUsers(){
     this.supportService.getSupportUsersInfo().subscribe(
      {
         next: (data) =>{
          console.log(data);
         },
         complete: () =>{
          console.log("Completed fetching users");
         },
          error: (error) =>{
            console.log("error", error);
          }
      }
     );
  }


}
