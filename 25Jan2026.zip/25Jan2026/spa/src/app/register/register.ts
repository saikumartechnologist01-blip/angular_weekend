import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { noSpaceValidator } from '../Custom.Validator';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './register.html',
  styleUrl: './register.css',
})
export class Register {


  registerForm:FormGroup = new FormGroup({

     username: new FormControl('',[Validators.required,
      Validators.minLength(6),
      Validators.maxLength(10),
      noSpaceValidator
    ]),
     password: new FormControl('',Validators.required),

  });

}
