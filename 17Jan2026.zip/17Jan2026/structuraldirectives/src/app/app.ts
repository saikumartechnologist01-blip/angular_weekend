import { Component, signal } from '@angular/core';
import { User } from './user/user';
import { ForgotPassword } from './forgot-password/forgot-password';
import { Products } from './products/products';
import { AttributeDemo } from './attribute-demo/attribute-demo';

@Component({
  selector: 'app-root',
  imports: [User,ForgotPassword,Products,AttributeDemo],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
 
}
