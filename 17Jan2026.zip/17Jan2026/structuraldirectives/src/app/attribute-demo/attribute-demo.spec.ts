import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttributeDemo } from './attribute-demo';

describe('AttributeDemo', () => {
  let component: AttributeDemo;
  let fixture: ComponentFixture<AttributeDemo>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AttributeDemo]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AttributeDemo);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
