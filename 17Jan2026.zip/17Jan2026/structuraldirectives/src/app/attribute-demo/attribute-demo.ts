import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-attribute-demo',
  imports: [CommonModule],
  templateUrl: './attribute-demo.html',
  styleUrl: './attribute-demo.css',
})
export class AttributeDemo {

   colorVariable: boolean = true;
   bold: boolean = true;
   italic: boolean = true;
   underline: boolean = true;  
   colorValue:string = "green";
   boldValue:string = "bold";
   italicValue:string = "italic"


}
