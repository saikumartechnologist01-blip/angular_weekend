import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-products',
  imports: [CommonModule],
  templateUrl: './products.html',
  styleUrl: './products.css',
})
export class Products {


   productList = [{name: 'Phone', price: 50000, image:"https://rukminim2.flixcart.com/image/240/240/xif0q/mobile/o/d/1/-original-imahggetmzzanrty.jpeg?q=60"},
     {name: 'Refrigerator', price: 20000,image:"https://rukminim2.flixcart.com/image/240/240/xif0q/refrigerator-new/q/5/g/-original-imahg65j3ryrsfyt.jpeg?q=60"}, 
     {name: 'Air Conditioner', price: 15000, image:"https://rukminim2.flixcart.com/image/240/240/xif0q/air-conditioner-new/y/x/5/-original-imah8ugkbhwwvw8g.jpeg?q=60"}];


}
