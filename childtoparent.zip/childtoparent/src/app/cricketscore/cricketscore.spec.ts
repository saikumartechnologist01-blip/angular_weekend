import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Cricketscore } from './cricketscore';

describe('Cricketscore', () => {
  let component: Cricketscore;
  let fixture: ComponentFixture<Cricketscore>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Cricketscore]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Cricketscore);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
