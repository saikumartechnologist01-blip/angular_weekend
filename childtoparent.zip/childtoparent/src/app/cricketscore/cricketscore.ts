import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-cricketscore',
  imports: [],
  templateUrl: './cricketscore.html',
  styleUrl: './cricketscore.css',
})
export class Cricketscore {
 
   score:string = "";

   @Output() scoreChange= new EventEmitter<string>();
  
   generateRandomScore(){
    return Math.floor(Math.random() * 300).toString() + "/" + Math.floor(Math.random() * 10).toString(); //
   }
   getScore(){
    this.score = this.generateRandomScore();
      this.scoreChange.emit(this.score);
   }

}
