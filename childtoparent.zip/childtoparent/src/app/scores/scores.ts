import { Component } from '@angular/core';
import { Cricketscore } from '../cricketscore/cricketscore';

@Component({
  selector: 'app-scores',
  imports: [Cricketscore],
  templateUrl: './scores.html',
  styleUrl: './scores.css',
})
export class Scores {

   cricketScore:string="";

  scoreChangeHandler(scoreInfo:string){
     this.cricketScore = scoreInfo;
  }

}
