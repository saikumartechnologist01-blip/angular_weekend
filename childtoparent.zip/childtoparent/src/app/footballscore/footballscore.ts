import { Component } from '@angular/core';

@Component({
  selector: 'app-footballscore',
  imports: [],
  templateUrl: './footballscore.html',
  styleUrl: './footballscore.css',
})
export class Footballscore {

}
