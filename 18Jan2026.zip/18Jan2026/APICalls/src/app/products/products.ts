import { Component } from '@angular/core';
import { Product } from '../product';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-products',
  imports: [CommonModule],
  templateUrl: './products.html',
  styleUrl: './products.css',
})
export class Products {

   productsList:any= [];

   constructor(private productService:Product){
      
   }

    fetchProducts(){

        this.productService.getProducts().subscribe({

          next: (response) => this.productsList = response,
          error: (error) => console.error(error),
          complete: () => console.log("API call completed")

        })

    }



}
