import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Product {

  // Dependency Injection: It is the process of providing the dependencies of a class from outside the class.

   constructor(private httpClient:HttpClient){

   }
   getProducts(){

    return this.httpClient.get("https://fakestoreapi.com/products");

   }
  

}
